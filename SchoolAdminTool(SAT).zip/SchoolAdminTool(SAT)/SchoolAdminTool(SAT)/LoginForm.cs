﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace SchoolAdminTool_SAT_
{
    public partial class LoginForm : Form
    {
        public static bool thisClosed;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void loginForm_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            thisClosed = false;
        }

        private void login_Click(object sender, EventArgs e)
        {
            performLogin();
        }

        public static string encryptPassword(string password)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(password);
            byte[] inArray = HashAlgorithm.Create("SHA1").ComputeHash(bytes);
            return Convert.ToBase64String(inArray);
        }

        private void performLogin()
        {
            login.Enabled = false;
            if (username.Text == "")
            {
                MessageBox.Show("Please enter a valid Username.", "Invalid Username", MessageBoxButtons.OK, MessageBoxIcon.Error);
                login.Enabled = true;
                username.Focus();
            }
            else if (password.Text == "")
            {
                MessageBox.Show("Please enter a valid Password.", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                login.Enabled = true;
                password.Focus();
            }
            else
            {
                var encryptedPassword = encryptPassword(password.Text);
                LoginStatusForm lsf = new LoginStatusForm();
                lsf.setCredentials(username.Text, encryptedPassword);
                login.Enabled = true;
                thisClosed = true;
                this.Close();
                thisClosed = false;
                lsf.Show();
            }
        }

        public void resetForm(String _username)
        {
            username.Text = _username;
            password.Text = "";
            password.Focus();
        }

        private void LoginForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!thisClosed)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }
    }
}
