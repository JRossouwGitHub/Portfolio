﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Firebase.Database;
using Firebase.Database.Query;
using System.Reactive.Linq;
using Newtonsoft.Json;
using System.Security.Cryptography;

namespace SchoolAdminTool_SAT_
{
    public partial class LoginStatusForm : Form
    {
        public static Timer loginTimer;
        private static String username;
        private static String password;
        public static bool thisClosed;

        public LoginStatusForm()
        {
            InitializeComponent();
        }

        private void loginStatusForm_Load(object sender, EventArgs e)
        {
            this.CenterToParent();
            this.connectToDB();
            thisClosed = false;
        }

        async private void connectToDB()
        {
            startTimer();
            try
            {
                var auth = "iAEnKnqnVP4UJLYiUFVuN76U4j6jt9iLBz3UBfU5";
                var firebaseClient = new FirebaseClient(
                    "https://schooladminttool.firebaseio.com/",
                    new FirebaseOptions
                    {
                        AuthTokenAsyncFactory = () => Task.FromResult(auth)
                    }
                );

                var staff = await firebaseClient
                          .Child("staff")
                          .OrderByKey()
                          .StartAt("")
                          .LimitToFirst(100)
                          .OnceAsync<Staff>();

                Console.WriteLine("Items in Staff: " + staff.Count);

                status.Text = "Verifying your login details...";

                foreach (var member in staff)
                {
                    if (member.Key.ToLower().Equals(username.ToLower()))
                    {
                        var passwordFromServer = member.Object.password;
                        var encryptedPassword = encryptPassword(passwordFromServer);
                        checkPasswordMatch(encryptedPassword);
                        break;
                    }
                }
            }
            catch (Exception e)
            {
                status.Text = "Connection Failed! Please ensure you are connected to the internet and try again...";
                Console.WriteLine("Error connecting to Firebase: " + e);
            }
            
        }

        private void backToLogin_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.resetForm(username);
            lf.Show();
            thisClosed = true;
            this.Close();
            thisClosed = false;
        }

        private void enableBackBtn(object sender, EventArgs e)
        {
            if (backToLogin.Visible == false)
            {
                backToLogin.Enabled = true;
                backToLogin.Visible = true;
                loginTimer.Stop();
            }
        }

        private void startTimer()
        {
            loginTimer = new Timer();
            loginTimer.Interval = 3000;
            loginTimer.Tick += new EventHandler(enableBackBtn);
            loginTimer.Start();
        }

        private void LoginStatusForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (loginTimer.Interval > 0)
            {
                loginTimer.Stop();
            }

            if (!thisClosed)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        public void setCredentials(String _username, String _password)
        {
            username = _username;
            password = _password;
        }

        public static string encryptPassword(string password)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(password);
            byte[] inArray = HashAlgorithm.Create("SHA1").ComputeHash(bytes);
            return Convert.ToBase64String(inArray);
        }

        public void checkPasswordMatch(String _password)
        {
            if (password.GetHashCode() == _password.GetHashCode())
            {
                status.Text = "Login Successful!";
                SATMainForm sat = new SATMainForm();
                thisClosed = true;
                this.Close();
                thisClosed = false;
                sat.Show();
            }
            else
            {
                status.Text = "Login Failed! Please check your details and try again.";
                backToLogin.Enabled = true;
                backToLogin.Visible = true;
            }
        }
    }
}
