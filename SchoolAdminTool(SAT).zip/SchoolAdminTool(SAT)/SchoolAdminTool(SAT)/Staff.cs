﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminTool_SAT_
{
    class Staff
    {
        [JsonProperty(PropertyName = "first_name")]
        public String first_name { get; set; }

        [JsonProperty(PropertyName = "last_name")]
        public String last_name { get; set; }

        [JsonProperty(PropertyName = "phone")]
        public String phone { get; set; }

        [JsonProperty(PropertyName = "email")]
        public String email { get; set; }

        [JsonProperty(PropertyName = "address")]
        public String address { get; set; }

        [JsonProperty(PropertyName = "password")]
        public String password { get; set; }

        public Staff()
        {
            
        }

        public Staff(String _first_name, String _last_name, String _address, String _phone, String _email, String _password)
        {
            this.first_name = _first_name;
            this.last_name = _last_name;
            this.phone = _phone;
            this.email = _email;
            this.address = _address;
            this.password = _password;
        }

        public String getName()
        {
            var name = "" + this.first_name + " " + this.last_name + "";
            return name;
        }

        public String getAddress()
        {
            return this.address;
        }

        public String getPhone()
        {
            return phone;
        }

        public String getEmail()
        {
            return this.email;
        }
    }
}
