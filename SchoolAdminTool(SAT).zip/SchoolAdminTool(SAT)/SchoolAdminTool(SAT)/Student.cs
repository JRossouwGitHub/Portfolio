﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminTool_SAT_
{
    class Student
    {
        [JsonProperty(PropertyName = "ID")]
        public int ID { get; set; }
        [JsonProperty(PropertyName = "first_name")]
        public String first_name { get; set; }
        [JsonProperty(PropertyName = "last_name")]
        public String last_name { get; set; }
        [JsonProperty(PropertyName = "phone")]
        public int phone { get; set; }
        [JsonProperty(PropertyName = "email")]
        public String email { get; set; }
        [JsonProperty(PropertyName = "address")]
        public String address { get; set; }
        [JsonProperty(PropertyName = "password")]
        public String password { get; set; }

        public Student()
        {

        }

        public Student(int _ID, String _first_name, String _last_name, int _phone, String _email, String _address, String _password)
        {
            this.ID = _ID;
            this.first_name = _first_name;
            this.last_name = _last_name;
            this.phone = _phone;
            this.email = _email;
            this.address = _address;
            this.password = _password;
        }
    }
}
