﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Firebase.Database;
using Firebase.Database.Query;
using System.Reactive.Linq;
using Newtonsoft.Json;
using System.Security.Cryptography;

namespace SchoolAdminTool_SAT_
{
    public partial class SATMainForm : Form
    {
        public static bool thisClosed;
        public FirebaseClient DB;

        public SATMainForm()
        {
            InitializeComponent();
        }

        private void SATMainForm_Load(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Hide();
            thisClosed = true;
            lf.Close();
            thisClosed = false;

            DB = connectToDB();
            //addToDB_STAFF("staff", "test", DB, "", "", 0, "", "","");
            populateList(DB);
        }

        private void SATMainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!thisClosed)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private FirebaseClient connectToDB()
        {
            try
            {
                var auth = "iAEnKnqnVP4UJLYiUFVuN76U4j6jt9iLBz3UBfU5";
                var firebaseClient = new FirebaseClient(
                    "https://schooladminttool.firebaseio.com/",
                    new FirebaseOptions
                    {
                        AuthTokenAsyncFactory = () => Task.FromResult(auth)
                    }
                );

                return firebaseClient;
            }
            catch (Exception e)
            {
                Console.WriteLine("Error connecting to DB: " + e);
                return null;
            }
            
        }

        async private void addToDB_STAFF(String _table, String _itemName, FirebaseClient _firebaseClient, String first_name, String last_name, String address, String phone, String email, String password)
        {
            await _firebaseClient
                .Child("" + _table + "")
                .Child("" + _itemName + "")
                .PutAsync(new Staff(first_name, last_name, address, phone, email, password));
        }

        async private void addToDB_STUDENT(String _table, String _itemName, FirebaseClient _firebaseClient)
        {
            await _firebaseClient
                .Child("" + _table + "")
                .Child("" + _itemName + "")
                .PutAsync(new Student());
        }

        async private void addToDB_COURSE(String _table, String _itemName, FirebaseClient _firebaseClient)
        {
            await _firebaseClient
                .Child("" + _table + "")
                .Child("" + _itemName + "")
                .PutAsync(new Course());
        }

        async private void populateList(FirebaseClient _firebaseClient)
        {
            var staff = await _firebaseClient
                          .Child("staff")
                          .OrderByKey()
                          .StartAt("")
                          .LimitToFirst(100)
                          .OnceAsync<Staff>();

            foreach (var member in staff)
            {
                ListViewItem item = new ListViewItem(member.Object.getName());
                item.SubItems.Add(member.Object.getAddress());
                item.SubItems.Add(member.Object.getPhone());
                item.SubItems.Add(member.Object.getEmail());
                staffListView.Items.Add(item);
            }
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            searchList(DB);
        }

        async private void searchList(FirebaseClient _firebaseClient)
        {
            var staff = await _firebaseClient
                          .Child("staff")
                          .OrderByKey()
                          .StartAt("")
                          .LimitToFirst(100)
                          .OnceAsync<Staff>();

            staffListView.Items.Clear();

            foreach (var member in staff)
            {
                if (member.Object.getName().ToLower().Contains(searchBox.Text.ToLower()))
                {
                    ListViewItem item = new ListViewItem(member.Object.getName());
                    item.SubItems.Add(member.Object.getAddress());
                    item.SubItems.Add(member.Object.getPhone());
                    item.SubItems.Add(member.Object.getEmail());
                    staffListView.Items.Add(item);
                    Console.WriteLine("Match");
                }
            }
        }
    }
}
