﻿namespace SchoolAdminTool_SAT_
{
    partial class LoginStatusForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pleaseWait = new System.Windows.Forms.Label();
            this.statusTitle = new System.Windows.Forms.Label();
            this.status = new System.Windows.Forms.Label();
            this.backToLogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pleaseWait
            // 
            this.pleaseWait.AutoSize = true;
            this.pleaseWait.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pleaseWait.Location = new System.Drawing.Point(13, 13);
            this.pleaseWait.Name = "pleaseWait";
            this.pleaseWait.Size = new System.Drawing.Size(476, 29);
            this.pleaseWait.TabIndex = 0;
            this.pleaseWait.Text = "Please wait while we attempt to log you in...";
            // 
            // statusTitle
            // 
            this.statusTitle.AutoSize = true;
            this.statusTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusTitle.Location = new System.Drawing.Point(16, 57);
            this.statusTitle.Name = "statusTitle";
            this.statusTitle.Size = new System.Drawing.Size(65, 24);
            this.statusTitle.TabIndex = 1;
            this.statusTitle.Text = "Status:";
            // 
            // status
            // 
            this.status.AutoSize = true;
            this.status.Location = new System.Drawing.Point(26, 94);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(116, 13);
            this.status.TabIndex = 2;
            this.status.Text = "Connecting to Server...";
            // 
            // backToLogin
            // 
            this.backToLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.backToLogin.Enabled = false;
            this.backToLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backToLogin.Location = new System.Drawing.Point(12, 157);
            this.backToLogin.Name = "backToLogin";
            this.backToLogin.Size = new System.Drawing.Size(552, 49);
            this.backToLogin.TabIndex = 3;
            this.backToLogin.Text = "Back To Login";
            this.backToLogin.UseVisualStyleBackColor = true;
            this.backToLogin.Visible = false;
            this.backToLogin.Click += new System.EventHandler(this.backToLogin_Click);
            // 
            // LoginStatusForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 261);
            this.Controls.Add(this.backToLogin);
            this.Controls.Add(this.status);
            this.Controls.Add(this.statusTitle);
            this.Controls.Add(this.pleaseWait);
            this.Name = "LoginStatusForm";
            this.Text = "Login Status";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LoginStatusForm_FormClosed);
            this.Load += new System.EventHandler(this.loginStatusForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pleaseWait;
        private System.Windows.Forms.Label statusTitle;
        private System.Windows.Forms.Label status;
        private System.Windows.Forms.Button backToLogin;
    }
}